export function calculateFormula(base: number, multiplier: number): number {
  return base * multiplier;
}