import React from 'react';

interface StatInputProps {
  value: number;
  disabled?: boolean;
  onChange: (newVal: number) => void;
}

export const StatInput: React.FC<StatInputProps> = ({ value, disabled, onChange }) => {
  return (
    <input
      type="number"
      value={value}
      disabled={disabled}
      onChange={(e) => onChange(parseFloat(e.target.value))}
      className="border p-1 rounded w-full disabled:opacity-50"
    />
  );
};