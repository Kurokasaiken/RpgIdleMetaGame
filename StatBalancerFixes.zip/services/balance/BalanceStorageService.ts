export class BalanceStorageService {
  private data: Record<string, number> = {};

  setStat(key: string, value: number): void {
    this.data[key] = value;
  }

  getStat(key: string): number {
    return this.data[key] ?? 0;
  }

  getAll(): Record<string, number> {
    return { ...this.data };
  }

  reset(): void {
    this.data = {};
  }
}