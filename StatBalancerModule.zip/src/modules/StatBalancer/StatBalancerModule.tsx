import React, { useState, useEffect } from 'react';
import { useStatContext } from '@/core/StatContext';
import { BalanceStorageService } from '@/services/BalanceStorageService';
import { Button } from '@/components/ui/button';
import { BalancerInputs } from './BalancerInputs';

export const StatBalancerModule: React.FC = () => {
  const { stats, setStat, locked, toggleLock, registerStat, unregisterStat, listSnapshotNames } = useStatContext();
  const [snapshotName, setSnapshotName] = useState('');
  const [snapshots, setSnapshots] = useState<string[]>([]);

  useEffect(() => {
    // register base stats on mount
    ['hp', 'damage', 'hitToKo'].forEach(registerStat);
    setSnapshots(listSnapshotNames());
  }, []);

  const handleSave = () => {
    if (!snapshotName) return;
    BalanceStorageService.saveSnapshot(snapshotName, stats, locked);
    setSnapshots(listSnapshotNames());
  };

  const handleLoad = (name: string) => {
    const snap = BalanceStorageService.loadSnapshot(name);
    if (snap) {
      Object.entries(snap.stats).forEach(([key, val]) => setStat(key, val));
      snap.locked.forEach((key) => toggleLock(key));
    }
  };

  const handleDelete = (name: string) => {
    BalanceStorageService.deleteSnapshot(name);
    setSnapshots(listSnapshotNames());
  };

  return (
    <div className="p-4 bg-gray-900 text-white rounded-lg">
      <h2 className="text-2xl mb-4">Bilanciamento Statistiche</h2>
      <div className="flex gap-2 items-center mb-4">
        <input
          type="text"
          placeholder="Nome snapshot"
          value={snapshotName}
          onChange={(e) => setSnapshotName(e.target.value)}
          className="px-3 py-1 rounded-md bg-gray-800"
        />
        <Button onClick={handleSave}>Salva</Button>
      </div>
      <div className="flex gap-2 mb-4">
        {snapshots.map((name) => (
          <div key={name} className="flex items-center gap-1">
            <span>{name}</span>
            <Button size="sm" variant="outline" onClick={() => handleLoad(name)}>↻</Button>
            <Button size="sm" variant="destructive" onClick={() => handleDelete(name)}>✕</Button>
          </div>
        ))}
      </div>
      <BalancerInputs
        stats={stats}
        locked={locked}
        onChange={(key, val) => setStat(key, val)}
        onToggleLock={toggleLock}
      />
    </div>
  );
};