import React from 'react';
import { StatSlider } from '@/components/ui/StatSlider';
import { Checkbox } from '@/components/ui/button';

interface BalancerInputsProps {
  stats: Record<string, number>;
  locked: Set<string>;
  onChange: (key: string, value: number) => void;
  onToggleLock: (key: string) => void;
}

export const BalancerInputs: React.FC<BalancerInputsProps> = ({
  stats, locked, onChange, onToggleLock
}) => {
  return (
    <div className="grid grid-cols-1 gap-4">
      {Object.entries(stats).map(([key, value]) => (
        <div key={key} className="flex items-center gap-4">
          <label className="w-24">{key}</label>
          <StatSlider
            value={value}
            min={0}
            max={999}
            disabled={locked.has(key)}
            onChange={(val) => onChange(key, val)}
          />
          <span className="w-12">{value}</span>
          <input
            type="checkbox"
            checked={locked.has(key)}
            onChange={() => onToggleLock(key)}
            className="form-checkbox h-5 w-5"
          />
        </div>
      ))}
    </div>
  );
};